#ifndef __MCABBER_XMPP_IQREQUEST_H__
#define __MCABBER_XMPP_IQREQUEST_H__ 1

void xmpp_iq_request(const char *fulljid, const char *xmlns);

#endif /* __MCABBER_XMPP_IQREQUEST_H__ */

/* vim: set et cindent cinoptions=>2\:2(0 ts=2 sw=2:  For Vim users... */
