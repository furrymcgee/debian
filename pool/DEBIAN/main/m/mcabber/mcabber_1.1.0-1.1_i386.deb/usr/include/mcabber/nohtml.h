#ifndef __MCABBER_NOHTML_H__
#define __MCABBER_NOHTML_H__ 1

char *html_strip(const char *buf);
char *html_escape(const char *text);

#endif /* __MCABBER_NOHTML_H__ */

/* vim: set et cindent cinoptions=>2\:2(0 ts=2 sw=2:  For Vim users... */
