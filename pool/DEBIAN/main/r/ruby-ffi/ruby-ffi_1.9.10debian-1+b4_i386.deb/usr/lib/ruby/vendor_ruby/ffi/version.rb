module FFI
  VERSION = '1.9.10'
end

